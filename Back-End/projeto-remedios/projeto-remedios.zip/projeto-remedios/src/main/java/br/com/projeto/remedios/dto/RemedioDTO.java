package br.com.projeto.remedios.dto;

import java.io.Serializable;

import br.com.projeto.remedios.entity.Remedio;

public class RemedioDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idRemedio;
	private String nomeRemedio;
	private MedicamentoPacienteDTO medicamentoPaciente;

	public RemedioDTO() {
	}

	public RemedioDTO(Integer idRemedio, String nomeRemedio, MedicamentoPacienteDTO medicamentoPaciente) {
		super();
		this.idRemedio = idRemedio;
		this.nomeRemedio = nomeRemedio;
		this.medicamentoPaciente = medicamentoPaciente;
	}

	public Remedio convertToEntity() {
		return new Remedio(getIdRemedio(), getNomeRemedio(), getMedicamentoPaciente().convertToEntity());
	}

	public Integer getIdRemedio() {
		return idRemedio;
	}

	public void setIdRemedio(Integer idRemedio) {
		this.idRemedio = idRemedio;
	}

	public String getNomeRemedio() {
		return nomeRemedio;
	}

	public void setNomeRemedio(String nomeRemedio) {
		this.nomeRemedio = nomeRemedio;
	}

	public MedicamentoPacienteDTO getMedicamentoPaciente() {
		return medicamentoPaciente;
	}

	public void setMedicamentoPaciente(MedicamentoPacienteDTO medicamentoPaciente) {
		this.medicamentoPaciente = medicamentoPaciente;
	}

}
