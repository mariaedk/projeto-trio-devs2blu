package br.com.projeto.remedios.controller;

public class MedicamentoPacienteController {

	public MedicamentoPacienteController() {
		// TODO Auto-generated constructor stub
	}

}
