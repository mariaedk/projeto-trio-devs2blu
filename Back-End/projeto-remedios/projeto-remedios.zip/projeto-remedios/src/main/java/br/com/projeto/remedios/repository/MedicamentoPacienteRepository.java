package br.com.projeto.remedios.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import br.com.projeto.remedios.entity.MedicamentoPaciente;
import br.com.projeto.remedios.entity.Paciente;

@Repository
public interface MedicamentoPacienteRepository extends JpaRepository<MedicamentoPaciente, Integer> {

	//tem que chamar a lista de pcientes verificar se escreve assim
	public List<Paciente> findByNomeContaining(String nome);

}
