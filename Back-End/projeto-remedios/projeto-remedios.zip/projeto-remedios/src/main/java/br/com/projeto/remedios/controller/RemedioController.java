package br.com.projeto.remedios.controller;

public class RemedioController {

	public RemedioController() {
		// TODO Auto-generated constructor stub
	}

}
