package br.com.projeto.remedios.dto;

import java.io.Serializable;

import br.com.projeto.remedios.entity.Paciente;

public class PacienteDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idPaciente;
	private Integer telefonePaciente;
	private String nomePaciente;
	private String generoPaciente;
	private MedicamentoPacienteDTO medicamentoPaciente;

	public Paciente convertToEntity() {
		return new Paciente(getIdPaciente(), getTelefonePaciente(), getNomePaciente(), getGeneroPaciente(), getMedicamentoPaciente().convertToEntity());
	}

	public PacienteDTO() {
		super();
	}

	public PacienteDTO(Integer idPaciente, Integer telefonePaciente, String nomePaciente, String generoPaciente,
		MedicamentoPacienteDTO medicamentoPaciente) {
	super();
	this.idPaciente = idPaciente;
	this.telefonePaciente = telefonePaciente;
	this.nomePaciente = nomePaciente;
	this.generoPaciente = generoPaciente;
	this.medicamentoPaciente = medicamentoPaciente;
}

	public Integer getTelefonePaciente() {
		return telefonePaciente;
	}

	public void setTelefonePaciente(Integer telefonePaciente) {
		this.telefonePaciente = telefonePaciente;
	}

	public Integer getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(Integer idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getNomePaciente() {
		return nomePaciente;
	}

	public void setNomePaciente(String nomePaciente) {
		this.nomePaciente = nomePaciente;
	}

	public String getGeneroPaciente() {
		return generoPaciente;
	}

	public void setGeneroPaciente(String generoPaciente) {
		this.generoPaciente = generoPaciente;
	}

	public MedicamentoPacienteDTO getMedicamentoPaciente() {
		return medicamentoPaciente;
	}

	public void setMedicamentoPaciente(MedicamentoPacienteDTO medicamentoPaciente) {
		this.medicamentoPaciente = medicamentoPaciente;
	}

}
