package br.com.projeto.remedios.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import br.com.projeto.remedios.dto.MedicamentoPacienteDTO;

@Entity
public class MedicamentoPaciente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(length = 50, nullable = false)
	private String frequencia;

	@Column
	private Integer frequenciaUso;

	public MedicamentoPaciente(Integer id, String frequencia, Integer frequenciaUso) {
		super();
		this.id = id;
		this.frequencia = frequencia;
		this.frequenciaUso = frequenciaUso;
	}

	public MedicamentoPaciente() {
	}

	public MedicamentoPacienteDTO getDTO() {
		return new MedicamentoPacienteDTO(getId(), getFrequencia(), getFrequenciaUso());
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFrequencia() {
		return frequencia;
	}

	public void setFrequencia(String frequencia) {
		this.frequencia = frequencia;
	}

	public Integer getFrequenciaUso() {
		return frequenciaUso;
	}

	public void setFrequenciaUso(Integer frequenciaUso) {
		this.frequenciaUso = frequenciaUso;
	}

}
