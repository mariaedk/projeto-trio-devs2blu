package br.com.projeto.remedios.service;

import org.springframework.stereotype.Service;

@Service
public class MedicamentoPacienteService {

	public MedicamentoPacienteService() {
		// TODO Auto-generated constructor stub
	}

}
