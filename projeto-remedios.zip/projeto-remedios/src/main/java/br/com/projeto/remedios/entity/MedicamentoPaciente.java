package br.com.projeto.remedios.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import br.com.projeto.remedios.dto.MedicamentoPacienteDTO;

@Entity
public class MedicamentoPaciente {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(length = 50, nullable = false)
	private String frequencia;

	@Column
	private Integer frequenciaUso;

	@ManyToOne
	@JoinColumn(name = "id_paciente")
	private Paciente paciente;

	@ManyToOne
	@JoinColumn(name = "id_remedio")
	private Remedio remedio;

	/**
	 * 
	 * U - Medicamento em uso P - Medicamento pausado F - Medicamento finalizado I -
	 * Medicamento interrompido
	 */
	@Column(length = 1)
	private String statusMedicamentoUso;

	public MedicamentoPaciente(Integer id, String frequencia, Integer frequenciaUso, Paciente paciente, Remedio remedio,
			String statusMedicamentoUso) {
		super();
		this.id = id;
		this.frequencia = frequencia;
		this.frequenciaUso = frequenciaUso;
		this.paciente = paciente;
		this.remedio = remedio;
		this.statusMedicamentoUso = statusMedicamentoUso;
	}

	public MedicamentoPaciente() {
	}

	public MedicamentoPacienteDTO getDTO() {
		return new MedicamentoPacienteDTO(getId(), getFrequencia(), getFrequenciaUso(), getPaciente().getDTO(),
				getRemedio().getDTO(), getStatusMedicamentoUso());
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFrequencia() {
		return frequencia;
	}

	public void setFrequencia(String frequencia) {
		this.frequencia = frequencia;
	}

	public Integer getFrequenciaUso() {
		return frequenciaUso;
	}

	public void setFrequenciaUso(Integer frequenciaUso) {
		this.frequenciaUso = frequenciaUso;
	}

	public Paciente getPaciente() {
		return paciente;
	}

	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}

	public Remedio getRemedio() {
		return remedio;
	}

	public void setRemedio(Remedio remedio) {
		this.remedio = remedio;
	}

	public String getStatusMedicamentoUso() {
		return statusMedicamentoUso;
	}

	public void setStatusMedicamentoUso(String statusMedicamentoUso) {
		this.statusMedicamentoUso = statusMedicamentoUso;
	}

}
