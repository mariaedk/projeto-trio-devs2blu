package br.com.projeto.remedios.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.projeto.remedios.dto.MedicamentoPacienteDTO;
import br.com.projeto.remedios.entity.MedicamentoPaciente;
import br.com.projeto.remedios.repository.MedicamentoPacienteRepository;

@Service
public class MedicamentoPacienteService {

	@Autowired
	MedicamentoPacienteRepository repository;

	public List<MedicamentoPacienteDTO> getAll() {
		List<MedicamentoPaciente> medicamentoPacientes = repository.findAll();
		List<MedicamentoPacienteDTO> listaMedicamentoPacienteDTO = new ArrayList();

		for (MedicamentoPaciente medicamentoPaciente : medicamentoPacientes) {
			listaMedicamentoPacienteDTO.add(medicamentoPaciente.getDTO());
		}
		return listaMedicamentoPacienteDTO;
	}

	public MedicamentoPacienteDTO getById(Integer id) throws Exception {
		MedicamentoPaciente medicamentoPaciente = repository.findById(id)
				.orElseThrow(() -> new Exception("Não foi encontrado o id"));
		return medicamentoPaciente.getDTO();
	}

	public MedicamentoPacienteDTO add(MedicamentoPacienteDTO medicamentoPaciente) {
		return repository.save(medicamentoPaciente.convertToEntity()).getDTO();
	}

	public Boolean delete(Integer id) throws Exception {
		MedicamentoPaciente medicamentoPaciente = repository.findById(id)
				.orElseThrow(() -> new Exception("Não foi encontrado o id"));
		repository.delete(medicamentoPaciente);
		return true;
	}

	public MedicamentoPacienteDTO update(MedicamentoPacienteDTO medicamentoPaciente) throws Exception {
		getById(medicamentoPaciente.getIdMedicamentoPaciente());
		return add(medicamentoPaciente);
	}

}
