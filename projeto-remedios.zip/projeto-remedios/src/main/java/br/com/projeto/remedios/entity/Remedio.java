package br.com.projeto.remedios.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import br.com.projeto.remedios.dto.MedicamentoPacienteDTO;
import br.com.projeto.remedios.dto.RemedioDTO;

@Entity
public class Remedio {

	public Remedio() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(length = 20, nullable = false)
	private String nome;

	@OneToMany(mappedBy = "remedio")
	private List<MedicamentoPaciente> medicamentoPaciente = new ArrayList<>();

	public Remedio(Integer id, String nome, List<MedicamentoPaciente> medicamentoPaciente) {
		super();
		this.id = id;
		this.nome = nome;
		this.medicamentoPaciente = medicamentoPaciente;
	}

	public RemedioDTO getDTO() {
		return new RemedioDTO(getId(), getNome(), getListMedicamentoPacienteDTO());
	}
	
	private List<MedicamentoPacienteDTO> getListMedicamentoPacienteDTO() {
		List<MedicamentoPacienteDTO> list = new ArrayList<>();
		
		for (MedicamentoPaciente medPac: getMedicamentoPaciente()) {
			list.add(medPac.getDTO());
		}
		return list;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public List<MedicamentoPaciente> getMedicamentoPaciente() {
		return medicamentoPaciente;
	}

	public void setMedicamentoPaciente(List<MedicamentoPaciente> medicamentoPaciente) {
		this.medicamentoPaciente = medicamentoPaciente;
	}

}
