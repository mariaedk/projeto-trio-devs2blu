package br.com.projeto.remedios.dto;

import java.io.Serializable;

import br.com.projeto.remedios.entity.MedicamentoPaciente;
import br.com.projeto.remedios.entity.Paciente;
import br.com.projeto.remedios.entity.Remedio;

public class MedicamentoPacienteDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idMedicamentoPaciente;
	private String frequencia;
	private Integer frequenciaUso;
	private PacienteDTO paciente;
	private RemedioDTO remedio;
	private String statusMedicamentoUso;

	public MedicamentoPaciente convertToEntity() {
		return new MedicamentoPaciente(getIdMedicamentoPaciente(), getFrequencia(), getFrequenciaUso(),
				getPaciente().convertToEntity(), getRemedio().convertToEntity(), getStatusMedicamentoUso());
	}

	public MedicamentoPacienteDTO() {
		super();
	}

	public MedicamentoPacienteDTO(Integer idMedicamentoPaciente, String frequencia, Integer frequenciaUso,
			PacienteDTO paciente, RemedioDTO remedio, String statusMedicamentoUso) {
		super();
		this.idMedicamentoPaciente = idMedicamentoPaciente;
		this.frequencia = frequencia;
		this.frequenciaUso = frequenciaUso;
		this.paciente = paciente;
		this.remedio = remedio;
		this.statusMedicamentoUso = statusMedicamentoUso;
	}

	public Integer getIdMedicamentoPaciente() {
		return idMedicamentoPaciente;
	}

	public void setIdMedicamentoPaciente(Integer idMedicamentoPaciente) {
		this.idMedicamentoPaciente = idMedicamentoPaciente;
	}

	public String getFrequencia() {
		return frequencia;
	}

	public void setFrequencia(String frequencia) {
		this.frequencia = frequencia;
	}

	public Integer getFrequenciaUso() {
		return frequenciaUso;
	}

	public void setFrequenciaUso(Integer frequenciaUso) {
		this.frequenciaUso = frequenciaUso;
	}

	public PacienteDTO getPaciente() {
		return paciente;
	}

	public void setPaciente(PacienteDTO paciente) {
		this.paciente = paciente;
	}

	public RemedioDTO getRemedio() {
		return remedio;
	}

	public void setRemedio(RemedioDTO remedio) {
		this.remedio = remedio;
	}

	public String getStatusMedicamentoUso() {
		return statusMedicamentoUso;
	}

	public void setStatusMedicamentoUso(String statusMedicamentoUso) {
		this.statusMedicamentoUso = statusMedicamentoUso;
	}

}
