package br.com.projeto.remedios.entity;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import br.com.projeto.remedios.dto.MedicamentoPacienteDTO;
import br.com.projeto.remedios.dto.PacienteDTO;

@Entity
public class Paciente {

	public Paciente() {
	}

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column
	private Integer telefone;

	@Column(length = 20, nullable = false)
	private String nome;

	@Column(length = 20, nullable = false)
	private String genero;

	@OneToMany(mappedBy = "paciente")
	private List<MedicamentoPaciente> medicamentoPaciente = new ArrayList<>();

	public Paciente(Integer id, Integer telefone, String nome, String genero,
			List<MedicamentoPaciente> medicamentoPaciente) {
		super();
		this.id = id;
		this.telefone = telefone;
		this.nome = nome;
		this.genero = genero;
		this.medicamentoPaciente = medicamentoPaciente;
	}

	public PacienteDTO getDTO() {
		return new PacienteDTO(getId(), getTelefone(), getNome(), getGenero(), getListMedicamentoPacienteDTO());
	}

	private List<MedicamentoPacienteDTO> getListMedicamentoPacienteDTO() {
		List<MedicamentoPacienteDTO> list = new ArrayList<>();
		
		for (MedicamentoPaciente medPac: getMedicamentoPaciente()) {
			list.add(medPac.getDTO());
		}
		return list;
	}
	
	public List<MedicamentoPaciente> getMedicamentoPaciente() {
		return medicamentoPaciente;
	}

	public void setMedicamentoPaciente(List<MedicamentoPaciente> medicamentoPaciente) {
		this.medicamentoPaciente = medicamentoPaciente;
	}

	public Integer getTelefone() {
		return telefone;
	}

	public void setTelefone(Integer telefone) {
		this.telefone = telefone;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getGenero() {
		return genero;
	}

	public void setGenero(String genero) {
		this.genero = genero;
	}

}
