package br.com.projeto.remedios.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.com.projeto.remedios.entity.MedicamentoPaciente;
import br.com.projeto.remedios.entity.Remedio;

public class RemedioDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idRemedio;
	private String nomeRemedio;
	private List<MedicamentoPacienteDTO> medicamentoPaciente = new ArrayList<>();

	public RemedioDTO() {
	}

	public RemedioDTO(Integer idRemedio, String nomeRemedio, List<MedicamentoPacienteDTO> medicamentoPaciente) {
		super();
		this.idRemedio = idRemedio;
		this.nomeRemedio = nomeRemedio;
		this.medicamentoPaciente = medicamentoPaciente;
	}

	public Remedio convertToEntity() {
		return new Remedio(getIdRemedio(), getNomeRemedio(), getListMedicamentoPacienteEntity());
	}

	private List<MedicamentoPaciente> getListMedicamentoPacienteEntity() {
		List<MedicamentoPaciente> list = new ArrayList<>();

		for (MedicamentoPacienteDTO medPacDTO : getMedicamentoPaciente()) {
			list.add(medPacDTO.convertToEntity());
		}
		return list;
	}

	public Integer getIdRemedio() {
		return idRemedio;
	}

	public void setIdRemedio(Integer idRemedio) {
		this.idRemedio = idRemedio;
	}

	public String getNomeRemedio() {
		return nomeRemedio;
	}

	public void setNomeRemedio(String nomeRemedio) {
		this.nomeRemedio = nomeRemedio;
	}

	public List<MedicamentoPacienteDTO> getMedicamentoPaciente() {
		return medicamentoPaciente;
	}

	public void setMedicamentoPaciente(List<MedicamentoPacienteDTO> medicamentoPaciente) {
		this.medicamentoPaciente = medicamentoPaciente;
	}

}
