package br.com.projeto.remedios.dto;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import br.com.projeto.remedios.entity.MedicamentoPaciente;
import br.com.projeto.remedios.entity.Paciente;

public class PacienteDTO implements Serializable {

	private static final long serialVersionUID = 1L;
	private Integer idPaciente;
	private Integer telefonePaciente;
	private String nomePaciente;
	private String generoPaciente;
	private List<MedicamentoPacienteDTO> medicamentoPaciente = new ArrayList<>();

	public Paciente convertToEntity() {
		return new Paciente(getIdPaciente(), getTelefonePaciente(), getNomePaciente(), getGeneroPaciente(),
				getListMedicamentoPacienteEntity());
	}

	private List<MedicamentoPaciente> getListMedicamentoPacienteEntity() {
		List<MedicamentoPaciente> list = new ArrayList<>();
		
		for (MedicamentoPacienteDTO medPacDTO : getMedicamentoPaciente()) {
			list.add(medPacDTO.convertToEntity());
		}
		return list;
	}

	public PacienteDTO() {
		super();
	}

	public PacienteDTO(Integer idPaciente, Integer telefonePaciente, String nomePaciente, String generoPaciente,
			List<MedicamentoPacienteDTO> medicamentoPaciente) {
		super();
		this.idPaciente = idPaciente;
		this.telefonePaciente = telefonePaciente;
		this.nomePaciente = nomePaciente;
		this.generoPaciente = generoPaciente;
		this.medicamentoPaciente = medicamentoPaciente;
	}

	public Integer getTelefonePaciente() {
		return telefonePaciente;
	}

	public void setTelefonePaciente(Integer telefonePaciente) {
		this.telefonePaciente = telefonePaciente;
	}

	public Integer getIdPaciente() {
		return idPaciente;
	}

	public void setIdPaciente(Integer idPaciente) {
		this.idPaciente = idPaciente;
	}

	public String getNomePaciente() {
		return nomePaciente;
	}

	public void setNomePaciente(String nomePaciente) {
		this.nomePaciente = nomePaciente;
	}

	public String getGeneroPaciente() {
		return generoPaciente;
	}

	public void setGeneroPaciente(String generoPaciente) {
		this.generoPaciente = generoPaciente;
	}

	public List<MedicamentoPacienteDTO> getMedicamentoPaciente() {
		return medicamentoPaciente;
	}

	public void setMedicamentoPaciente(List<MedicamentoPacienteDTO> medicamentoPaciente) {
		this.medicamentoPaciente = medicamentoPaciente;
	}

}
