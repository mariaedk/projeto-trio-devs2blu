package br.com.projeto.remedios;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoRemediosApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoRemediosApplication.class, args);
	}

}
