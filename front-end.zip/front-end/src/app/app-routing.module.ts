import { CadastroRemedioComponent } from './components/remedio/cadastro-remedio/cadastro-remedio.component';
import { CadastroPacienteComponent } from './components/paciente/cadastro-paciente/cadastro-paciente.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {path:'cadastro-paciente', component: CadastroPacienteComponent},
  {path:'cadastro-remedio', component: CadastroRemedioComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
