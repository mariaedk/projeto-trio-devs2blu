import { RemedioService } from './../../../services/remedio/remedio.service';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';
import { Remedio } from './../../../models/remedio/remedio';
import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-update-remedio',
  templateUrl: './update-remedio.component.html',
  styleUrls: ['./update-remedio.component.scss']
})
export class UpdateRemedioComponent implements OnInit {

  @Input()
  remedioEdit = new Remedio({});

  @Input()
  statusEdit = new Subject<boolean>();

  myDate = new Date();
  dataFinalizacao: NgbDate = new NgbDate(0, 0, 0);

  constructor(private remedioService: RemedioService) { }

  ngOnInit(): void {

  }

  update(remedio: Remedio)
  {
    if (remedio)
    {
      this.dataFinalizacao.month = this.dataFinalizacao.month - 1;
      this.myDate = new Date(this.dataFinalizacao.year, this.dataFinalizacao.month, this.dataFinalizacao.day);
      this.remedioEdit.deadLineRemedio = this.myDate;
      this.remedioService.updateRemedio(remedio).subscribe(
        resp =>
        {
          if (resp)
          {
            console.log("modificado");
            this.updateStatus(true);
          }
          else
          {
            this.updateStatus(false);
          }
        }
      )
    }
  }

  updateStatus(status: boolean)
  {
    this.remedioEdit = new Remedio({});
    this.statusEdit.next(status);
  }

  cancelUpdate()
  {
    this.statusEdit.next(false);
  }
}
