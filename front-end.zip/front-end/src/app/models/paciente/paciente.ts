export class Paciente {
}
