export class Remedio {
}
