import { Remedio } from './remedio';

describe('Remedio', () => {
  it('should create an instance', () => {
    expect(new Remedio()).toBeTruthy();
  });
});
