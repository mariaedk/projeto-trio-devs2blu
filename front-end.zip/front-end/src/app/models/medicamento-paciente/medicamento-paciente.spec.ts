import { MedicamentoPaciente } from './medicamento-paciente';

describe('MedicamentoPaciente', () => {
  it('should create an instance', () => {
    expect(new MedicamentoPaciente()).toBeTruthy();
  });
});
