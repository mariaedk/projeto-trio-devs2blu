export class Remedio
{
  id?: number;
  nome?: string;
  hora?: number;

  constructor(obj: Partial<Remedio>)
  {
    Object.assign(this, obj);
  }
}
