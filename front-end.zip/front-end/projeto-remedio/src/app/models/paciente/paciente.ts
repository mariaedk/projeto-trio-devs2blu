import { Remedio } from './../remedio/remedio';
export class Paciente
{
  id?: number;
  nome?: string;
  genero?: string;
  telefone?: string;
  remedios?: Remedio[];

  constructor(obj: Partial<Paciente>)
  {
    Object.assign(this, obj);
  }
}
